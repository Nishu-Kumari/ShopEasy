//
//  HamburgerViewController.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 29/10/23.
//

import UIKit

protocol HamburgerViewControllerDelegate {
    func hideHamburgerMenu()
}

class HamburgerViewController: UIViewController {

    var delegate: HamburgerViewControllerDelegate?

    @IBOutlet weak var profilePictureImage: UIImageView!
    @IBOutlet weak var mainBackgroundView: UIView!

    @IBOutlet weak var homeButton: UIButton!
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!

    
    @IBOutlet weak var nameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupHamburgerUI()
        // Do any additional setup after loading the view.
    }

    private func setupHamburgerUI() {
        mainBackgroundView.layer.cornerRadius = 40
        mainBackgroundView.clipsToBounds = true

        profilePictureImage.layer.cornerRadius = 40
        profilePictureImage.clipsToBounds = true

        // Set icons for buttons using system images
        homeButton.setImage(UIImage(systemName: "house.fill"), for: .normal)
        profileButton.setImage(UIImage(systemName: "person.fill"), for: .normal)
        logoutButton.setImage(UIImage(systemName: "arrow.left.circle.fill"), for: .normal)
    }

    @IBAction func clickedOnButton(_ sender: UIButton) {
        switch sender {
        case homeButton:
            // Handle home button click
            navigateToHome()
        case profileButton:
            // Handle profile button click
            break
        case logoutButton:
            // Handle logout button click
            self.delegate?.hideHamburgerMenu()
            // Navigate to the LoginViewController
            navigateToLogin()
        default:
            break
        }
    }

    private func navigateToLogin() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil) // Change "Main" to the name of your storyboard
        if let loginViewController = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            // Assuming "LoginViewController" is the identifier of your LoginViewController in the storyboard
            navigationController?.pushViewController(loginViewController, animated: true)
        }
    }

    private func navigateToHome() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil) // Change "Main" to the name of your storyboard
        if let homeViewController = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            // Assuming "HomeViewController" is the identifier of your HomeViewController in the storyboard
            navigationController?.pushViewController(homeViewController, animated: true)
        }
    }
}
                                                                                                                                       
