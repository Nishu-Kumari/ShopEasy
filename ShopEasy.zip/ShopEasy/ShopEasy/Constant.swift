//
//  Constant.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 29/10/23.
//

enum Constant {
    enum API {
        static let productURL = "http://fakestoreapi.com/products"
    }
}
