//
//  NetworkManager.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 29/10/23.
//

import Foundation

class NetworkManager: NSObject {
    static let shared = NetworkManager()
    
    private override init() {
        super.init()
    }
    
    private let session: URLSession = {
        let sessionConfig = URLSessionConfiguration.default
        sessionConfig.waitsForConnectivity = true
        sessionConfig.timeoutIntervalForResource = 120
        return URLSession(configuration: sessionConfig, delegate: shared, delegateQueue: nil)
    }()

    func fetchData() {
        // Use your `session` to make requests
    }
}

extension NetworkManager: URLSessionDelegate {
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
            if let serverTrust = challenge.protectionSpace.serverTrust {
                let credential = URLCredential(trust: serverTrust)
                completionHandler(.useCredential, credential)
            } else {
                completionHandler(.performDefaultHandling, nil)
            }
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }
}

