//
//  Product.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 29/10/23.
//

struct Product: Decodable {
    let id: Int
    let title: String
    let price: Float
    let description: String
    let category: String
    let image: String
    let rating: Rate
}

struct Rate: Decodable {
    let rate: Float
    let count: Int
}
