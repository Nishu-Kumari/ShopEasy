//
//  User+CoreDataClass.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 20/10/23.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
