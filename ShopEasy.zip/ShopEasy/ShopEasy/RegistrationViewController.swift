//
//  RegistrationViewController.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 20/10/23.
//

import UIKit

 

class RegistrationViewController: UIViewController {

 

    @IBOutlet weak var nameTextField: UITextField!

    @IBOutlet weak var emailTextField: UITextField!

    @IBOutlet weak var phoneNumberTextField: UITextField!

    @IBOutlet weak var passwordTextField: UITextField!

    @IBOutlet weak var confirmPasswordTextField: UITextField!

 

    override func viewDidLoad() {

        super.viewDidLoad()

    }

 

    @IBAction func registerTapped(_ sender: UIButton) {

        guard let name = nameTextField.text, !name.isEmpty,

              let email = emailTextField.text, !email.isEmpty,

              let phoneNumber = phoneNumberTextField.text, !phoneNumber.isEmpty,

              let password = passwordTextField.text, !password.isEmpty,

              let confirmPassword = confirmPasswordTextField.text, !confirmPassword.isEmpty else {

            showAlert(title: "Missing Information", message: "Please fill in all required fields.")

            return

        }

 

        guard isNameValid(name) else {

            showAlert(title: "Invalid Name", message: "Name should have at least 3 characters and contain only alphabetic characters.")

            return

        }

 

        guard isEmailValid(email) else {

            showAlert(title: "Invalid Email", message: "Please enter a valid email address.")

            return

        }

 

        guard isPhoneNumberValid(phoneNumber) else {

            showAlert(title: "Invalid Phone Number", message: "Phone number should be 10 digits long and start with 6, 7, 8, or 9.")

            return

        }

 

        guard isPasswordValid(password) else {

            showAlert(title: "Invalid Password", message: "Password should have at least 8 characters, one upper case letter, one lower case letter, one digit, and one special character.")

            return

        }

 

        guard doPasswordMatch(password, confirmPassword) else {

            showAlert(title: "Password Mismatch", message: "Password and confirm password do not match. Please re-enter.")

            return

        }

 

        // Proceed with registration if all input is valid

        let userData = ["name": name, "email": email, "phoneNumber": phoneNumber, "password": password]

        DatabaseHelper.sharedInstance.saveUser(data: userData)

 

        // Display a success alert

        showAlert(title: "Success", message: "Registration successful!")

 

        // Clear text fields or perform other actions as needed

        nameTextField.text = ""

        emailTextField.text = ""

        phoneNumberTextField.text = ""

        passwordTextField.text = ""

        confirmPasswordTextField.text = ""

    }

 

    @IBAction func loginTapped(_ sender: UIButton) {

        // Transition to the login view controller.

        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        if let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {

            self.navigationController?.pushViewController(loginVC, animated: true)

        }

    }

 

    private func isNameValid(_ name: String) -> Bool {

        let nameRegex = "^[a-zA-Z]{3,}$"

        return NSPredicate(format: "SELF MATCHES %@", nameRegex).evaluate(with: name)

    }

 

    private func isEmailValid(_ email: String) -> Bool {

        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"

        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)

    }

 

    private func isPhoneNumberValid(_ phoneNumber: String) -> Bool {

        let phoneRegex = "^[6-9]\\d{9}$"

        return NSPredicate(format: "SELF MATCHES %@", phoneRegex).evaluate(with: phoneNumber)

    }

 

    private func isPasswordValid(_ password: String) -> Bool {

        let passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=]).{8,}$"

        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: password)

    }

 

    private func doPasswordMatch(_ password: String, _ confirmPassword: String) -> Bool {

        return password == confirmPassword

    }

 

    private func showAlert(title: String, message: String) {

        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))

        self.present(alert, animated: true, completion: nil)

    }

}



