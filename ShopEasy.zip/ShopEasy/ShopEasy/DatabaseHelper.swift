//
//  DatabaseHelper.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 20/10/23.
//


import Foundation

import CoreData
import UIKit

 

class DatabaseHelper {

    static let sharedInstance = DatabaseHelper()

    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext

 

    func saveUser(data: [String: String]) {

        let user = User(context: context!)

        user.name = data["name"]

        user.email = data["email"]

        user.phoneNumber = data["phoneNumber"]

        user.password = data["password"]

 

        do {

            try context?.save()

        } catch {

            print("Error saving user: \(error)")

        }

    }

 

    func loginUser(email: String, password: String) -> User? {

        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()

        fetchRequest.predicate = NSPredicate(format: "email == %@ AND password == %@", email, password)

 

        do {

            let results = try context?.fetch(fetchRequest)

            if let user = results?.first {

                return user // User found, login successful.

            }

        } catch {

            print("Error fetching user data: \(error)")

        }

        return nil // User not found or error occurred, login failed.

    }

 

    func userExists(email: String) -> Bool {

        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()

        fetchRequest.predicate = NSPredicate(format: "email == %@", email)

 

        do {

            let results = try context?.fetch(fetchRequest)

            return results?.count ?? 0 > 0

        } catch {

            print("Error checking user existence: \(error)")

        }

        return false

    }

}

