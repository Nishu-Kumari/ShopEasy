//
//  ViewController.swift
//  ShopEasy
//
//  Created by Nishu Kumari on 20/10/23.
//
import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

 

    override func viewDidLoad() {
        super.viewDidLoad()
    }

 

    @IBAction func loginTapped(_ sender: UIButton) {
        // Check if email and password fields are empty
        guard let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showAlert(title: "Missing Credentials", message: "Please enter both email and password.")
            return
        }

 

        // Attempt to login using Core Data
        if let user = DatabaseHelper.sharedInstance.loginUser(email: email, password: password) {
            // Successfully logged in
            // Navigate to home page
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            self.navigationController?.pushViewController(homeVC, animated: true)
        } else {
            // Login failed
            showAlert(title: "Login Failed", message: "Invalid email or password.")
        }
    }

 

    @IBAction func registerTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let registrationVC = storyboard.instantiateViewController(withIdentifier: "RegistrationViewController") as! RegistrationViewController
        self.navigationController?.pushViewController(registrationVC, animated: true)
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}





